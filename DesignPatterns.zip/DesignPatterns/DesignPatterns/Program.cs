﻿using System;

namespace DesignPatterns
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Learning Head First Design Patterns the hard way...");
            Console.ReadKey();
        }
    }
}
