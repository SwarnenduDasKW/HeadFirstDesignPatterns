﻿using System;

namespace TheObserverPattern
{
    class CurrentConditionDisplay : IObserver, IDisplayElement
    {
        private double temparature;
        private double humidity;
        private ISubject weatherData;

        public CurrentConditionDisplay(ISubject wd)
        {
            weatherData = wd;
            weatherData.registerObserver(this);
        }

        public void display()
        {
            Console.WriteLine("Current Weather Condition: Temparature:{0} degree C and Humidity:{1}%",temparature.ToString(),humidity.ToString());
        }

        public void update(double temp, double humidity, double pressure)
        {
            this.temparature = temp;
            this.humidity = humidity;
            display();
        }
    }
}
