﻿using System;

namespace TheObserverPattern
{
    class ForecastDisplay : IObserver, IDisplayElement
    {
        private double currentPressure = 26;
        private double previousPressure;
        private WeatherData weatherData;
        public ForecastDisplay(WeatherData wd)
        {
            this.weatherData = wd;
            weatherData.registerObserver(this);
        }   
        
        public void display()
        {
            Console.Write("Today's forecast: ");
            if (currentPressure > previousPressure)
            {
                Console.WriteLine("Improving weather on the way!");
            }
            else if (currentPressure == previousPressure)
            {
                Console.WriteLine("More of the same");
            }
            else if (currentPressure < previousPressure)
            {
                Console.WriteLine("Watch out for cooler, rainy weather");
            }
        }

        public void update(double temp, double humidity, double pressure)
        {
            previousPressure = currentPressure;
            currentPressure = pressure;

            display();
        }
    }
}
