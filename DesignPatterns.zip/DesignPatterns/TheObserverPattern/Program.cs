﻿using System;

namespace TheObserverPattern
{
    class Program
    {
        static void Main(string[] args)                                                                       
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("=============================");
            Console.WriteLine("Welcome to Weather Station!!");
            Console.WriteLine("=============================");
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;

            WeatherData wd = new WeatherData();

            CurrentConditionDisplay cd = new CurrentConditionDisplay(wd);
            ForecastDisplay fd = new ForecastDisplay(wd);
            StatisticsDisplay sd = new StatisticsDisplay(wd);
            HeatIndexDisplay hid = new HeatIndexDisplay(wd);

            wd.setMeasurement(22.00, 65, 30.5);
            Console.WriteLine();
            Console.WriteLine();
            wd.setMeasurement(25.50, 55, 45.56);
            Console.WriteLine();
            Console.WriteLine();
            wd.setMeasurement(20.15, 45, 50.33);
            Console.WriteLine();
            Console.WriteLine();
            wd.setMeasurement(18.45, 30, 51.34);
            Console.WriteLine();
            Console.WriteLine();

            Console.ReadKey();
        }
    }
}
