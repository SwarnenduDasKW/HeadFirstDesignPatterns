﻿using System;

namespace TheObserverPattern
{
    class StatisticsDisplay : IObserver, IDisplayElement
    {
        private double maxTemp = 0.00;
        private double minTemp = 200;
        private double avgTemp = 0.00;
        private double tempSum = 0.00;

        private int noOfReadings;

        private WeatherData weatherData;
        public StatisticsDisplay(WeatherData wd)
        {
            this.weatherData = wd;
            weatherData.registerObserver(this);
        }
        public void display()
        {
            Console.WriteLine("Temparature Statistics: Avg = {0} || Max = {1} || Min = {2}",avgTemp,maxTemp,minTemp);
        }

        public void update(double temp, double humidity, double pressure)
        {
            tempSum += temp;
            noOfReadings++;

            if (temp > maxTemp)
                maxTemp = temp;

            if (temp < minTemp)
                minTemp = temp;


            avgTemp = tempSum / noOfReadings;

            display();

        }
    }
}
