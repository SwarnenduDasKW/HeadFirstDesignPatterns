﻿using System.Collections.Generic;

namespace TheObserverPattern
{
    class WeatherData : ISubject
    {
        private List<IObserver> observers;
        private double temperature;
        private double humidity;
        private double pressure;

        public WeatherData()
        {
            observers = new List<IObserver>();
        }

        public void registerObserver(IObserver o)
        {
            observers.Add(o);
        }

        public void removeObserver(IObserver o)
        {
            int i = observers.IndexOf(o);
            if(i >= 0)
            {
                observers.RemoveAt(i);
            }
        }

        public void notifyObserver()
        {
            foreach (IObserver o in observers)
            {
                o.update(temperature, humidity, pressure);
            }
        }

        public void measurementChanged()
        {
            notifyObserver();
        }

        public void setMeasurement(double t, double h, double p)
        {
            temperature = t;
            humidity = h;
            pressure = p;
            measurementChanged();
        }
    }
}
